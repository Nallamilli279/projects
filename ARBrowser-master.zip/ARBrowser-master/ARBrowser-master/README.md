# ARBrowser
## Voice operated web browser based on AR for Android

An Augmented Reality Web Browser where we will be able to interact and search using voice commands and results will appear in augmented reality, just the way many superhero movies like Ironman have shown.

### YouTube Playlist:

[![Watch the video](https://img.youtube.com/vi/eXpDaB4cevc/0.jpg)](https://www.youtube.com/watch?v=eXpDaB4cevc)

This app allows users to search web in an attractive and more effective manner whereby they can browse through the web through their voice and see the search trail infront of their eyes, and all this can be done while doing other tasks like for example eating breakfast, reading newspaper, laying down, etc.
