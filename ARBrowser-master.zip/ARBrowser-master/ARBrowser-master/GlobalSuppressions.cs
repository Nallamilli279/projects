﻿
// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Common Practices and Code Improvements", "RECS0030:Suggests using the class declaring a static function when calling it", Justification = "<Pending>", Scope = "member", Target = "~M:GoogleARCore.Examples.HelloAR.ARController.Update")]

